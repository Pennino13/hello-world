In my final project I created a web-application called "12 Hints". The purpose of this website is to establish a pool of cards,
which can than be used to play an "offline game". In order to do that the users can create cards, safe their drafts for new cards,
review other people's cards, give feedback and finally play cards (aka access a random card, which has been approved by other users).